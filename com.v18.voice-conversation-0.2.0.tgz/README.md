# Quest Voice Conversation

Unity Package Manager package for an XR Interaction Toolkit/Meta Quest scene where:

- the headset user speaks,
- partial speech is shown as text,
- a callback fires once the utterance is complete,
- recognition is canceled and blocked while avatar audio is playing.

The default Quest provider is Meta Voice SDK with Wit.ai. Android's system
`SpeechRecognizer` remains available as an optional fallback, but it is not the
recommended Quest provider.

## Requirements

- Unity 2021.3.26f1 or newer.
- Meta Quest 2, Quest 3, or Quest 3S.
- Meta Voice SDK (`com.meta.xr.sdk.voice`).
  - Use Voice SDK 71 for Unity 2021.3.
  - Use the current Voice SDK for Unity 2022.3.15f1 or newer.
- A configured Wit.ai application and internet connection.
- Android microphone permission and user consent for processing voice data.

Install Meta Voice SDK from the Unity Asset Store or Meta XR All-in-One SDK.
Then follow Meta's Voice SDK setup to create a `WitConfiguration`.

## Install This Package

This repository contains the package at:

`Packages/com.v18.voice-conversation`

To use it in another project, copy that folder into the target project's
`Packages` folder, or select:

`Window > Package Manager > + > Add package from disk...`

Then choose:

`Packages/com.v18.voice-conversation/package.json`

## Quest Project Settings

1. Switch the build target to Android.
2. Use ARM64 and IL2CPP.
3. Set `Player Settings > Other Settings > Internet Access` to `Require`.
4. Keep the package's `RECORD_AUDIO` permission in the merged Android manifest.
5. Request and explain voice-data consent before enabling recognition.

## Scene Setup

1. Create or configure a `WitConfiguration` using Meta Voice SDK.
2. Choose `Assets > Create > Voice SDK > Add App Voice Experience to Scene`.
3. Assign the `WitConfiguration` to the new `AppVoiceExperience` component.
4. Create an object named `Voice Conversation` and add `Voice Conversation Recognizer`.
5. Keep `Recognition Provider` set to `Meta Voice SDK`.
6. Assign `AppVoiceExperience` to `Meta Voice Experience`. It is also found automatically when there is only one in the scene.
7. Add `Avatar Speech Gate`, then assign the recognizer and avatar `AudioSource`.
8. Add `Transcript Text Target` to the TextMeshPro or Unity UI text object and assign the recognizer.
9. Bind `UserSpeechComplete(string)` to the function that sends the user's final text to your avatar/chat system.

The sample binding is:

`UserSpeechComplete(string) -> BasicAvatarConversationResponder.OnUserSpeechComplete(string)`

## Runtime Flow

`VoiceConversationRecognizer` activates Meta Voice SDK and emits:

- `TranscriptUpdated(string)` for partial and final text.
- `FinalTranscript(string)` for final recognized text.
- `UserSpeechComplete(string)` after Meta Voice SDK finishes the request.
- `RecognitionError(string)` for permission, configuration, or network errors.

`AvatarSpeechGate` watches the assigned avatar `AudioSource`.

- When avatar audio starts, it aborts the active voice request and adds a blocker.
- While audio is playing, delayed recognition results are ignored.
- When audio finishes, it removes the blocker and starts a fresh request after `Resume Delay Seconds`.

Route every avatar reply through the monitored `AudioSource`, or call
`AvatarStartedSpeaking()` and `AvatarFinishedSpeaking()` around custom playback.

## Android Native Fallback

`Android Native` can be selected for devices that provide an Android
`RecognitionService`. It is not reliable on stock Quest firmware and should not
be used as the production Quest path.

## Editor Testing

With Meta Voice SDK configured, Play mode can use live transcription. For an
offline event-wiring test, open the recognizer component context menu and choose
`Simulate Recognized Speech`.
