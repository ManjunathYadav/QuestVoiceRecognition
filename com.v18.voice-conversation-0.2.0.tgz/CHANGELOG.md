# Changelog

## 0.2.0 - 2026-06-29

- Added Meta Voice SDK `AppVoiceExperience` as the default Quest provider.
- Added partial and final transcription event bridging without a compile-time SDK dependency.
- Abort active Meta voice requests while avatar audio is playing.
- Ignore delayed results from canceled requests.
- Retained Android native recognition as an optional fallback.
- Added Android internet permission and Quest setup documentation.

## 0.1.0 - 2026-06-26

- Initial Android native speech recognition implementation.
- Added transcript events, speech-complete callback, and avatar audio gating.
