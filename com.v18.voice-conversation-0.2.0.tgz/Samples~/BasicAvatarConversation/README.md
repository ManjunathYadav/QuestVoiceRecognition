# Basic Avatar Conversation Sample

1. Install Meta Voice SDK and add a configured `AppVoiceExperience` to the scene.
2. Add `Voice Conversation Recognizer`, keep `Meta Voice SDK` selected, and assign `AppVoiceExperience`.
3. Add `Avatar Speech Gate` to the avatar or audio object, assign the recognizer and avatar `AudioSource`.
4. Add `Transcript Text Target` to a TextMeshPro/Unity UI text object, then assign the recognizer.
5. Import this sample and add `BasicAvatarConversationResponder` to any scene object.
6. Bind `VoiceConversationRecognizer.UserSpeechComplete(string)` to `BasicAvatarConversationResponder.OnUserSpeechComplete(string)`.
7. Assign a sample avatar reply clip. While that clip plays, the active request is aborted and recognition is blocked.

With Meta Voice SDK configured, Play mode supports live transcription. The recognizer's **Simulate Recognized Speech** context menu remains available for offline event testing.
