using System;

namespace V18.VoiceConversation.Platform
{
    internal sealed class UnsupportedSpeechRecognizerBackend : IPlatformSpeechRecognizer
    {
        private readonly string supportMessage;
        private Action<SpeechBackendEvent> eventSink;

        public UnsupportedSpeechRecognizerBackend(
            string message = "Speech recognition is not supported on this platform.")
        {
            supportMessage = message;
        }

        public bool IsSupported
        {
            get { return false; }
        }

        public string SupportMessage
        {
            get { return supportMessage; }
        }

        public void Initialize(SpeechRecognizerSettings settings, Action<SpeechBackendEvent> sink)
        {
            eventSink = sink;
        }

        public void StartListening()
        {
            if (eventSink != null)
            {
                eventSink(SpeechBackendEvent.Error(-1, SupportMessage));
            }
        }

        public void StopListening()
        {
        }

        public void CancelListening()
        {
        }

        public void Dispose()
        {
            eventSink = null;
        }
    }
}
