using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.Events;

namespace V18.VoiceConversation.Platform
{
    internal sealed class MetaVoiceSdkSpeechRecognizerBackend : IPlatformSpeechRecognizer
    {
        private const string AppVoiceExperienceTypeName = "Oculus.Voice.AppVoiceExperience";

        private readonly List<ListenerBinding> listenerBindings = new List<ListenerBinding>();

        private Action<SpeechBackendEvent> eventSink;
        private MonoBehaviour voiceExperience;
        private object voiceEvents;
        private MethodInfo activateMethod;
        private MethodInfo deactivateMethod;
        private MethodInfo abortMethod;
        private MethodInfo canActivateAudioMethod;
        private MethodInfo canSendMethod;
        private MethodInfo getActivateAudioErrorMethod;
        private MethodInfo getSendErrorMethod;
        private string pendingFinalTranscript;
        private bool requestFailed;
        private bool supported;
        private string supportMessage;

        public bool IsSupported
        {
            get { return supported; }
        }

        public string SupportMessage
        {
            get { return supportMessage; }
        }

        public void Initialize(SpeechRecognizerSettings settings, Action<SpeechBackendEvent> sink)
        {
            eventSink = sink;
            voiceExperience = ResolveVoiceExperience(settings.MetaVoiceExperience);

            if (voiceExperience == null)
            {
                supportMessage = "Meta Voice SDK is selected, but no AppVoiceExperience was found. Install com.meta.xr.sdk.voice, add AppVoiceExperience to the scene, configure its WitConfiguration, and assign it under Quest Provider.";
                return;
            }

            Type experienceType = voiceExperience.GetType();
            activateMethod = FindParameterlessMethod(experienceType, "Activate");
            deactivateMethod = FindParameterlessMethod(experienceType, "Deactivate");
            abortMethod = FindParameterlessMethod(experienceType, "DeactivateAndAbortRequest");
            canActivateAudioMethod = FindParameterlessMethod(experienceType, "CanActivateAudio");
            canSendMethod = FindParameterlessMethod(experienceType, "CanSend");
            getActivateAudioErrorMethod = FindParameterlessMethod(experienceType, "GetActivateAudioError");
            getSendErrorMethod = FindParameterlessMethod(experienceType, "GetSendError");

            PropertyInfo voiceEventsProperty = experienceType.GetProperty("VoiceEvents", BindingFlags.Public | BindingFlags.Instance);
            voiceEvents = voiceEventsProperty != null ? voiceEventsProperty.GetValue(voiceExperience, null) : null;

            if (activateMethod == null || deactivateMethod == null || voiceEvents == null)
            {
                supportMessage = "The assigned component is not a compatible Meta AppVoiceExperience. Update Meta Voice SDK or assign the AppVoiceExperience component itself.";
                return;
            }

            try
            {
                BindEvent("OnStartListening", new UnityAction(OnStartListening));
                BindEvent("OnMinimumWakeThresholdHit", new UnityAction(OnBeginningOfSpeech));
                BindEvent("OnStoppedListening", new UnityAction(OnStoppedListening));
                BindEvent("OnPartialTranscription", new UnityAction<string>(OnPartialTranscription));
                BindEvent("OnFullTranscription", new UnityAction<string>(OnFullTranscription));
                BindEvent("OnRequestCompleted", new UnityAction(OnRequestCompleted));
                BindEvent("OnError", new UnityAction<string, string>(OnError));
            }
            catch (Exception exception)
            {
                RemoveAllListeners();
                supportMessage = "Could not connect to Meta Voice SDK events: " + GetInnermostMessage(exception);
                return;
            }

            supported = true;
            supportMessage = "Meta Voice SDK AppVoiceExperience backend";
        }

        public void StartListening()
        {
            if (!supported)
            {
                return;
            }

            pendingFinalTranscript = string.Empty;
            requestFailed = false;

            if (!CheckCanStart(canActivateAudioMethod, getActivateAudioErrorMethod, "Meta Voice SDK cannot activate audio")
                || !CheckCanStart(canSendMethod, getSendErrorMethod, "Meta Voice SDK cannot send a request"))
            {
                return;
            }

            InvokeMethod(activateMethod, "Could not activate Meta Voice SDK");
        }

        public void StopListening()
        {
            InvokeMethod(deactivateMethod, "Could not stop Meta Voice SDK");
        }

        public void CancelListening()
        {
            pendingFinalTranscript = string.Empty;
            requestFailed = true;
            InvokeMethod(abortMethod ?? deactivateMethod, "Could not cancel Meta Voice SDK");
        }

        public void Dispose()
        {
            if (supported && voiceExperience != null && (abortMethod ?? deactivateMethod) != null)
            {
                try
                {
                    (abortMethod ?? deactivateMethod).Invoke(voiceExperience, null);
                }
                catch (Exception exception)
                {
                    Debug.LogWarning("Could not stop Meta Voice SDK during disposal: " + GetInnermostMessage(exception));
                }
            }

            RemoveAllListeners();
            eventSink = null;
            voiceEvents = null;
            voiceExperience = null;
            activateMethod = null;
            deactivateMethod = null;
            abortMethod = null;
            canActivateAudioMethod = null;
            canSendMethod = null;
            getActivateAudioErrorMethod = null;
            getSendErrorMethod = null;
            supported = false;
        }

        private MonoBehaviour ResolveVoiceExperience(MonoBehaviour configuredExperience)
        {
            if (IsAppVoiceExperience(configuredExperience))
            {
                return configuredExperience;
            }

            MonoBehaviour[] sceneBehaviours = UnityEngine.Object.FindObjectsOfType<MonoBehaviour>(true);
            for (int i = 0; i < sceneBehaviours.Length; i++)
            {
                if (IsAppVoiceExperience(sceneBehaviours[i]))
                {
                    return sceneBehaviours[i];
                }
            }

            return null;
        }

        private static bool IsAppVoiceExperience(MonoBehaviour behaviour)
        {
            if (behaviour == null)
            {
                return false;
            }

            Type type = behaviour.GetType();
            while (type != null)
            {
                if (type.FullName == AppVoiceExperienceTypeName)
                {
                    return true;
                }

                type = type.BaseType;
            }

            return false;
        }

        private static MethodInfo FindParameterlessMethod(Type type, string methodName)
        {
            return type.GetMethod(
                methodName,
                BindingFlags.Public | BindingFlags.Instance,
                null,
                Type.EmptyTypes,
                null);
        }

        private void BindEvent(string propertyName, Delegate listener)
        {
            PropertyInfo property = voiceEvents.GetType().GetProperty(propertyName, BindingFlags.Public | BindingFlags.Instance);
            object unityEvent = property != null ? property.GetValue(voiceEvents, null) : null;
            if (unityEvent == null)
            {
                throw new MissingMemberException(voiceEvents.GetType().FullName, propertyName);
            }

            MethodInfo addListener = unityEvent.GetType().GetMethod("AddListener", BindingFlags.Public | BindingFlags.Instance);
            if (addListener == null)
            {
                throw new MissingMethodException(unityEvent.GetType().FullName, "AddListener");
            }

            addListener.Invoke(unityEvent, new object[] { listener });
            listenerBindings.Add(new ListenerBinding(unityEvent, listener));
        }

        private void RemoveAllListeners()
        {
            for (int i = listenerBindings.Count - 1; i >= 0; i--)
            {
                ListenerBinding binding = listenerBindings[i];

                try
                {
                    MethodInfo removeListener = binding.UnityEvent.GetType().GetMethod(
                        "RemoveListener",
                        BindingFlags.Public | BindingFlags.Instance);

                    if (removeListener != null)
                    {
                        removeListener.Invoke(binding.UnityEvent, new object[] { binding.Listener });
                    }
                }
                catch (Exception exception)
                {
                    Debug.LogWarning("Could not disconnect a Meta Voice SDK listener: " + GetInnermostMessage(exception));
                }
            }

            listenerBindings.Clear();
        }

        private void InvokeMethod(MethodInfo method, string errorPrefix)
        {
            if (!supported || method == null || voiceExperience == null)
            {
                return;
            }

            try
            {
                method.Invoke(voiceExperience, null);
            }
            catch (Exception exception)
            {
                Emit(SpeechBackendEvent.Error(5, errorPrefix + ": " + GetInnermostMessage(exception)));
            }
        }

        private bool CheckCanStart(MethodInfo checkMethod, MethodInfo errorMethod, string errorPrefix)
        {
            if (checkMethod == null)
            {
                return true;
            }

            try
            {
                if ((bool)checkMethod.Invoke(voiceExperience, null))
                {
                    return true;
                }

                string detail = errorMethod != null
                    ? errorMethod.Invoke(voiceExperience, null) as string
                    : string.Empty;
                string message = string.IsNullOrEmpty(detail) ? errorPrefix : errorPrefix + ": " + detail;
                Emit(SpeechBackendEvent.Error(IsConfigurationError(message) ? 5 : 8, message));
                return false;
            }
            catch (Exception exception)
            {
                Emit(SpeechBackendEvent.Error(5, errorPrefix + ": " + GetInnermostMessage(exception)));
                return false;
            }
        }

        private void OnStartListening()
        {
            pendingFinalTranscript = string.Empty;
            requestFailed = false;
            Emit(SpeechBackendEvent.Ready());
        }

        private void OnBeginningOfSpeech()
        {
            Emit(SpeechBackendEvent.Beginning());
        }

        private void OnStoppedListening()
        {
            Emit(SpeechBackendEvent.End());
        }

        private void OnPartialTranscription(string transcript)
        {
            if (!string.IsNullOrWhiteSpace(transcript))
            {
                Emit(SpeechBackendEvent.Partial(transcript));
            }
        }

        private void OnFullTranscription(string transcript)
        {
            pendingFinalTranscript = transcript ?? string.Empty;
        }

        private void OnRequestCompleted()
        {
            if (requestFailed)
            {
                return;
            }

            string transcript = pendingFinalTranscript;
            pendingFinalTranscript = string.Empty;

            if (string.IsNullOrWhiteSpace(transcript))
            {
                Emit(SpeechBackendEvent.Error(7, "Meta Voice SDK completed without a transcription"));
                return;
            }

            Emit(SpeechBackendEvent.Final(transcript));
        }

        private void OnError(string errorCode, string errorMessage)
        {
            requestFailed = true;
            pendingFinalTranscript = string.Empty;

            string message = string.IsNullOrEmpty(errorCode)
                ? errorMessage
                : errorCode + ": " + errorMessage;

            Emit(SpeechBackendEvent.Error(IsConfigurationError(message) ? 5 : 2, message));
        }

        private static bool IsConfigurationError(string message)
        {
            if (string.IsNullOrEmpty(message))
            {
                return false;
            }

            string normalized = message.ToLowerInvariant();
            return normalized.Contains("401")
                || normalized.Contains("403")
                || normalized.Contains("token")
                || normalized.Contains("configuration");
        }

        private void Emit(SpeechBackendEvent speechEvent)
        {
            Action<SpeechBackendEvent> sink = eventSink;
            if (sink != null)
            {
                sink(speechEvent);
            }
        }

        private static string GetInnermostMessage(Exception exception)
        {
            while (exception.InnerException != null)
            {
                exception = exception.InnerException;
            }

            return exception.Message;
        }

        private struct ListenerBinding
        {
            public readonly object UnityEvent;
            public readonly Delegate Listener;

            public ListenerBinding(object unityEvent, Delegate listener)
            {
                UnityEvent = unityEvent;
                Listener = listener;
            }
        }
    }
}
