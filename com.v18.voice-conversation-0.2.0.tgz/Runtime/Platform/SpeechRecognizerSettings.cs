using UnityEngine;

namespace V18.VoiceConversation.Platform
{
    internal struct SpeechRecognizerSettings
    {
        public MonoBehaviour MetaVoiceExperience;
        public string Language;
        public bool PreferOfflineRecognition;
        public int CompleteSilenceMillis;
        public int PossiblyCompleteSilenceMillis;
        public int MaxResults;
    }
}
